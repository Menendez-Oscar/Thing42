import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Thing42<K, D> extends Pair<K, D> implements Thing42orNull<K, D> {
	
	public final String NPE_MESSAGE = "Argument cannot be null";

	final long level;

	private LinkedList<Thing42orNull<K,D>> pool;
	
	private Map<K, List<Thing42orNull<K,D>>> peers;
	
	public Thing42(K keyIn, long levelIn, D dataIn) {
		super(keyIn, dataIn);
		this.level = levelIn;
		this.pool = new LinkedList<Thing42orNull<K,D>>();
		this.peers = new HashMap<K, List<Thing42orNull<K,D>>>();
	}

	@Override
	public void addPeer(Thing42orNull<K, D> newPeer) {
		K key = newPeer.getKey();
		if (this.peers.get(key) == null) {
			this.peers.put(key, new LinkedList<Thing42orNull<K,D>>());
		}
		this.peers.get(key).add(newPeer);
	}

	@Override
	public void appendToPool(Thing42orNull<K, D> newMember) {
		nullCheck(newMember);
		this.pool.addLast(newMember);
	}

	@Override
	public long getLevel() {
		return this.level;
	}

	@Override
	public Thing42orNull<K, D> getOnePeer(Object key) {
		Thing42orNull<K, D> one = null;
		List<Thing42orNull<K,D>> matchingKeys = this.peers.get(key);
		if (matchingKeys != null && matchingKeys.size() > 0) {
			one = matchingKeys.get(0);
		}
		return one;
	}

	@Override
	public Collection<Thing42orNull<K, D>> getPeersAsCollection() {
		List<Thing42orNull<K,D>> retValue = new LinkedList<Thing42orNull<K,D>>();
		Collection<List<Thing42orNull<K, D>>> lists = this.peers.values();
		for (Collection<Thing42orNull<K,D>> list : lists) {
			retValue.addAll(list);
		}

		return retValue;
	}

	@Override
	public Collection<Thing42orNull<K, D>> getPeersAsCollection(Object key) {
		Collection<Thing42orNull<K, D>> mpeers = this.peers.get(key);
		return mpeers == null? new LinkedList<Thing42orNull<K,D>>() : mpeers;
	}

	@Override
	public List<Thing42orNull<K, D>> getPoolAsList() {
		return this.pool;
	}

	@Override
	public boolean removeFromPool(Thing42orNull<K, D> member) {
		nullCheck(member);
		return this.pool.remove(member);
	}

	@Override
	public boolean removePeer(Thing42orNull<K, D> peer) {
		return this.peers.get(peer.getKey()).remove(peer);
	}

	/**
	 * Checks for {@code null}
	 * @param obj the {@code Object} to check if {@code null}
	 * @throws NullPointerException if the parameter is {@code null}
	 */
	private void nullCheck(Object obj) throws NullPointerException {
		if (obj == null) {
			throw new NullPointerException(NPE_MESSAGE);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (int) (level ^ (level >>> 32));
		result = prime * result + ((peers == null) ? 0 : peers.hashCode());
		result = prime * result + ((pool == null) ? 0 : pool.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Thing42<?,?> other = (Thing42<?,?>) obj;
		if (level != other.level)
			return false;
		if (peers == null) {
			if (other.peers != null)
				return false;
		} else if (!peers.equals(other.peers))
			return false;
		if (pool == null) {
			if (other.pool != null)
				return false;
		} else if (!pool.equals(other.pool))
			return false;
		return true;
	}

}